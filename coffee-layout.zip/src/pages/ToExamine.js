import React from "react";

const ToExamine = () => {
  return <div></div>;
};

export default ToExamine;
